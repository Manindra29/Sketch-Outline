package sketchoutline.tool;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import processing.app.*;
import sketchoutline.tool.TreeMaker.TmNode;

public class SketchOutlineFrame extends JFrame {

	private JPanel contentPane;
	private JScrollPane scrollPane;
	public JTree tree;
	TreeMaker treeMaker = null;
	ThreadedTreeMaker thTreeMaker = null;
	Editor editor;
	int offset;
	TreePath lastpath;
	ArrayList<TreePath> lastExpandedPaths = new ArrayList<TreePath>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// TreeMaker tm = new TreeMaker(TreeMaker.PATH);
					SketchOutlineFrame frame = new SketchOutlineFrame(null);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SketchOutlineFrame(Editor edt) {
		final JFrame thisFrame = this;
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Unable to load System look and feel");
		}

		this.editor = edt;
		Base.setIcon(this);

		if (thTreeMaker == null) {

			if (editor != null) {
				// System.out.println(editor.getSketch().getCurrentCode()
				// .getProgram());
				thTreeMaker = new ThreadedTreeMaker(this, editor);
			} else {
				System.err.println("Editor is null");
				thTreeMaker = new ThreadedTreeMaker(this, null);
			}
		}

		if (thTreeMaker.treeMaker.treeCreated) {

			tree = new JTree(thTreeMaker.getTree());
			// treeMaker.offSet - 1;
			tree.setExpandsSelectedPaths(true);
			if (editor != null)
				thTreeMaker.treeMaker.sourceString = editor.getSketch()
						.getCurrentCode().getProgram();
			else
				thTreeMaker.treeMaker.sourceString = "";

			tree.addTreeSelectionListener(new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent event) {
					lastpath = event.getPath();
				}
			});

			tree.addMouseListener(new MouseListener() {

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseClicked(MouseEvent event) {
					if (thisFrame.hasFocus())
						return;
					DefaultMutableTreeNode n = (DefaultMutableTreeNode) tree
							.getLastSelectedPathComponent();
					if (n == null)
						return;
					// thTreeMaker.lastpath = event.getPath();
					if (lastpath != null)
						thTreeMaker.lastRow = (tree.getRowForPath(lastpath));
					//
					// System.out.println("tree select: " + ",, "
					// + thTreeMaker.lastRow);
					TmNode tn = (TmNode) n.getUserObject();
//					System.out.println("Clicked on: " + tn.label + " - "
//							+ tn.node.getBeginLine());

					try {

						offset = thTreeMaker.treeMaker.xyToOffset(
								tn.node.getBeginLine()
										- thTreeMaker.treeMaker.mainClassLineOffset,
								tn.node.getBeginColumn());
						// =
						// editor.getTextArea().xyToOffset(tn.node.getBeginLine()-
						// thTreeMaker.treeMaker.mainOffSet,
						// tn.node.getBeginColumn());

//						System.out.print("Line no: "
//								+ (tn.node.getBeginLine() - thTreeMaker.treeMaker.mainClassLineOffset));
						// + "," + tn.node.getBeginColumn());
						// System.out.println("Calculated Offset: " + offset);
						//
						// System.out.println("Editor offset: "
						// + editor.getCaretOffset());
						editor.toFront();
						editor.setSelection(offset, offset);

					} catch (Exception ex) {
						System.out.println("Error positioning cursor."
								+ ex.toString());

					}
				}
			});

			// tree.addTreeExpansionListener(new TreeExpansionListener() {
			//
			// @Override
			// public void treeExpanded(TreeExpansionEvent event) {
			//
			// Object arr[] = event.getPath().getPath();
			//
			// for (Object object : arr) {
			// System.out.println(object.toString());
			// }
			// TreePath tp = event.getPath();//new TreePath(arr);
			// System.out.println("Expand on: " + tp.toString());
			// if (lastExpandedPaths.size() == 0) {
			// lastExpandedPaths.add(tp);
			// } else {
			// for (int i = 0; i < lastExpandedPaths.size(); i++) {
			// TreePath path = lastExpandedPaths.get(i);
			// if (path.equals(tp))
			// System.out.println("eq");
			// else {
			// lastExpandedPaths.add(tp);
			// break;
			// }
			// }
			// }
			// System.out.println("Paths: " + lastExpandedPaths.size());
			// for (TreePath object : lastExpandedPaths) {
			// System.out.println(object);
			// }
			// System.out.println();
			// }
			//
			// @Override
			// public void treeCollapsed(TreeExpansionEvent event) {
			// TreePath tp = event.getPath();//new TreePath(arr);
			// System.out.println("Collapse on: " + tp.toString());
			// // if (lastExpandedPaths.size() == 0) {
			// // lastExpandedPaths.add(tp);
			// // } else {
			// // for (int i = 0; i < lastExpandedPaths.size(); i++) {
			// // TreePath path = lastExpandedPaths.get(i);
			// // if (path.equals(tp))
			// // System.out.println("eq");
			// // else {
			// // lastExpandedPaths.add(tp);
			// // break;
			// // }
			// // }
			// // }
			// lastExpandedPaths.remove(tp);
			// System.out.println("Paths: " + lastExpandedPaths.size());
			// for (TreePath object : lastExpandedPaths) {
			// System.out.println(object);
			// }
			// System.out.println();
			// }
			// });

		} else {
			System.err.println("Java file couldn't be parsed.");
		}

		thTreeMaker.start();

		setTitle("Outline - " + thTreeMaker.treeMaker.mainClassName);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// [width=234,height=376]

		setBounds(new Rectangle(100, 100, 260, 420));
		if (editor != null) {
			// setBounds(new Rectangle(100, editor.getlo, 260, 420));
			setLocation(new Point(editor.getLocation().x + editor.getWidth(),
					editor.getLocation().y));
		}
		setMinimumSize(new Dimension(260, 420));
		setFocusable(true);
		contentPane = new JPanel();
		contentPane.setBounds(new Rectangle(0, 0, 244, 382));
		// contentPane.setBounds(0, 0, 260, 420);
		// contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		scrollPane = new JScrollPane();
		// scrollPane.setBounds(0, 0, 260, 420);
		scrollPane.setViewportView(tree);
		scrollPane.setBounds(0, 0, 244, 382);
		contentPane.add(scrollPane);

		// scrollPane.s
		// setResizable(false);
		setVisible(true);
		setAlwaysOnTop(true);

		contentPane.addComponentListener(new ComponentListener() {

			@Override
			public void componentShown(ComponentEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void componentResized(ComponentEvent e) {
				// TODO Auto-generated method stub
				// e.getComponent().getSize();
//				System.out.println(e.getComponent().getSize().toString());
				// contentPane.setBounds(new Rectangle(0, 0, 244, 382));
				// scrollPane.setBounds(0,0,244,382);
				// setBounds(new Rectangle(100, 100, 260, 420));
				Dimension d = e.getComponent().getSize();
				if (d.width >= 244 && d.height >= 382) {
					// contentPane.setBounds(0, 0, d.width - 16, d.height - 38);
					scrollPane.setSize(d);
					scrollPane.update(scrollPane.getGraphics());
				} else {
					// thisFrame.setBounds(thisFrame.getX(), thisFrame.getY(),
					// 260, 420);
				}
				// contentPane.repaint();
				// contentPane.update(contentPane.getGraphics());

				// tree.update(tree.getGraphics());
				//
				// thisFrame.update(thisFrame.getGraphics());
			}

			@Override
			public void componentMoved(ComponentEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void componentHidden(ComponentEvent e) {
				// TODO Auto-generated method stub

			}
		});

	}

	public void dispose() {
		thTreeMaker.halt();
		setVisible(false);
	}
}
