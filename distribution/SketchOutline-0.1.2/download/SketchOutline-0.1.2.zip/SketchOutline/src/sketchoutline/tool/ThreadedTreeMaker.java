package sketchoutline.tool;

import java.awt.Component;
import java.util.ArrayList;

import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import processing.app.Editor;

import sketchoutline.tool.TreeMaker.TmNode;

public class ThreadedTreeMaker implements Runnable {

	TreeMaker treeMaker;// = null, treeMakerStatic = null;
	boolean stop = false;
	Thread thread;
	SketchOutlineFrame frame = null;
	TreePath lastpath = null;
	public int lastRow = 0;
	public final int fastTime = 1000, slowSleep = 3000;
	int sleepDuration;
	int buildCount = 1;

	public void run() {

		while (true) {

			if (stop)
				break;
			try {
				Thread.sleep(sleepDuration);

				if (treeMaker.editor != null) {
					if (treeMaker.editor.getSketch().getCurrentCode()
							.isModified()) {
						// System.out.println("Editor modified");
					} else {
						// System.out.println("Editor NOT modified");
						continue;
					}
				}
				if (frame.hasFocus())
					continue;
					
				if (treeMaker.buildTree()) {
					// treeMaker.calculateCursorLocation();
					// System.out.println("Tree Refreshed. " + ++buildCount);
					frame.tree.setModel(new DefaultTreeModel(getTree()));
					((DefaultTreeModel) frame.tree.getModel()).reload();

					// for (TreePath path : frame.lastExpandedPaths) {
					// frame.tree.expandPath(new TreePath(path.getPath()));
					// }
					// frame.lastExpandedPaths.clear();

					// Expand trees only if user is not interacting with the
					// frame
					if (!frame.hasFocus()) {
						for (int i = 0; i < frame.tree.getRowCount(); i++) {
							frame.tree.expandRow(i);
						}

						if (lastRow > 0) {
							// frame.tree.expandRow(lastRow);
							frame.tree.setSelectionRow(lastRow);
							// frame.tree.
							// System.out.println("Row expand.");
						}
					}
					frame.tree.repaint();
					frame.editor.toFront();
				}

				else {
					if (TreeMaker.debugMode)
						System.out.println("Tree not refreshed. ");
				}

			} catch (InterruptedException e) {
				System.err.println("ThreadedTreeMaker Interrupted! :(");
				if (TreeMaker.debugMode)
					e.printStackTrace();
			} catch (Exception e) {
				System.err
						.println("Some exception caught in ThreadedTreeMaker: "
								+ e.toString());
				if (TreeMaker.debugMode)
					e.printStackTrace();
			}
		}

	}

	public void updateTree() {
		try {

			if (treeMaker.buildTree()) {
				// System.out.println("Tree Refreshed. " + ++buildCount);
				frame.tree.setModel(new DefaultTreeModel(getTree()));
				((DefaultTreeModel) frame.tree.getModel()).reload();

				// for (TreePath path : frame.lastExpandedPaths) {
				// frame.tree.expandPath(new TreePath(path.getPath()));
				// }
				// frame.lastExpandedPaths.clear();
				for (int i = 0; i < frame.tree.getRowCount(); i++) {
					frame.tree.expandRow(i);
				}

				if (lastRow > 0) {
					// frame.tree.expandRow(lastRow);
					frame.tree.setSelectionRow(lastRow);
					// frame.tree.
					// System.out.println("Row expand.");
				}
				frame.tree.repaint();
				frame.editor.toFront();
			}

			else {
				if (TreeMaker.debugMode)
					System.out.println("Tree not refreshed. ");
			}

		} catch (Exception e) {
			System.err
					.println("Some exception caught in ThreadedTreeMaker Update: "
							+ e.toString());
			e.printStackTrace();
		}

	}

	public ThreadedTreeMaker() {
		treeMaker = new TreeMaker();
		// treeMakerStatic = new TreeMaker();
	}

	public ThreadedTreeMaker(String path) {
		treeMaker = new TreeMaker(path);
		// treeMakerStatic = new TreeMaker(path);
	}

	public ThreadedTreeMaker(SketchOutlineFrame frame, Editor editor) {
		treeMaker = new TreeMaker(editor);
		this.frame = frame;
		// treeMakerStatic = new TreeMaker(path);
	}

	public ThreadedTreeMaker(String path, SketchOutlineFrame frame) {
		treeMaker = new TreeMaker(path);
		this.frame = frame;
		// treeMakerStatic = new TreeMaker(path);
	}

	public DefaultMutableTreeNode getTree() {
		return treeMaker.getCodeTree();
	}

	public void halt() {
		if (thread == null)
			return;
		thread.stop();
		stop = true;
		System.out.println("Auto refresh OFF.");
	}

	public void resume() {
		stop = false;
	}

	public void start() {
		if (treeMaker.editor == null)
			sleepDuration = slowSleep;
		else
			sleepDuration = fastTime;

		// if (thread == null) {
		// thread = new Thread(this);
		// thread.start();
		// } else
		// thread.resume();
		thread = new Thread(this);
		thread.start();
		stop = false;
		System.out.println("Auto refresh ON.");
	}

	// public void setLastRow(int n) {
	// try {
	// thread.wait();
	// lastRow = n;
	// thread.resume();
	// } catch (InterruptedException e) {
	// // TODO Auto-generated catch block
	//
	// e.printStackTrace();
	// }
	//
	// }

	// public class NodeClicked implements TreeSelectionListener {
	//
	// @Override
	// public void valueChanged(TreeSelectionEvent e) {
	// DefaultMutableTreeNode n = (DefaultMutableTreeNode) frame.tree
	// .getLastSelectedPathComponent();
	// if (n == null) {
	// System.out.println("Last node null");
	// return;
	// }
	// lastpath = e.getPath();
	// System.out.println(n.toString());
	// TmNode tn = (TmNode) n.getUserObject();
	// try {
	// // if(editor!=null)
	// // frame.editor.setSelection(tn.node.getBeginLine() - offset,
	// // tn.node.getBeginLine() - offset);
	//
	// } catch (Exception ex) {
	// System.out.println("Error positioning cursor.");
	//
	// }
	// }
	//
	// }

}

// if(frame.tree.getse)
// if (lastpath != null) {
//
// TreePath path = new TreePath(lastpath.getPath());
// // if (frame.tree.isSelectionEmpty())
// // frame.tree.expandPath(lastpath);
// // else
// frame.tree.setSelectionPath(path);
// // frame.tree.getPathForRow(frame.tree.getRowCount());
// System.out.println("lastpath not null"
// + lastpath.toString()
// + frame.tree.getRowCount());
// } else {
// System.out.println("lastpath null");
// }
// System.out.println("Last row: " + lastRow);
// if (lastRow > 0) {
// // frame.tree.expandRow(lastRow);
// //frame.tree.setSelectionRow(lastRow);
// // frame.tree.
// //System.out.println("Row expand.");
// }
// frame.tree.expandPath(path)
// frame.tree.;
// NodeClicked nodeClickListener = new NodeClicked();
// frame.tree.addTreeSelectionListener(nodeClickListener);
