/**
 * you can put a one sentence description of your tool here.
 *
 * ##copyright##
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author		##author##
 * @modified	##date##
 * @version		##version##
 */

package sketchoutline.tool;

import java.awt.EventQueue;
import java.awt.Frame;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;

import processing.app.*;
import processing.app.tools.*;
import processing.mode.java.JavaBuild;

public class SketchOutline implements Tool {

	// when creating a tool, the name of the main class which implements Tool
	// must be the same as the value defined for project.name in your
	// build.properties

	Editor editor;

	public String getMenuTitle() {
		return "Sketch Outline";
	}

	public void init(Editor theEditor) {
		editor = theEditor;

	}

	SketchOutlineFrame frame;
	String path;
	JavaBuild jb;
	TreeMaker treemaker;

	public void run() {

		// Standard,Android, JavaScript

		System.out.println("Sketch Outline 0.1.2 (beta)");
		System.out.println("By - Manindra Moharana");
		String mode = editor.getMode().getTitle();
		if (mode.equals("Android") || mode.equals("JavaScript")) {
			System.out
					.println("This tool is still in beta and hasn't been tested throughly in "
							+ mode
							+ " mode. Please report any bugs in the issues section of the project page.");
		}
		try {

			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						if (frame == null) {
							frame = new SketchOutlineFrame(editor);
							// return;
						}
						frame.setVisible(true);
						frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

					} catch (Exception e) {
						System.err.println("Exception at Tool.run()");
						if (TreeMaker.debugMode)
							e.printStackTrace();
					}
				}
			});
		} catch (Exception e2) {
			System.err.println("Exception at Tool.run() - invokeLater");
			if (TreeMaker.debugMode)
				e2.printStackTrace();
		}

	}

}
